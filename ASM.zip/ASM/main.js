//-------------MENU------------//
$(document).ready(function () {
    $(".menu").click(function () {
        $("nav").slideToggle();
    });
});



//-------------SLIDE.BANNER-----------//
var hinh = [
    'img/banner1.jpg',
    'img/banner2.jpg',
   ' img/banner3.jpg',
];
var index=0;
function prev() {
    index--;
    if (index<0) index=hinh.length-1;
        document.getElementById('banner').src=hinh[index];
        document.getElementById('0').style.color='black';
        document.getElementById('1').style.color='black';
        document.getElementById('2').style.color='black';
        document.getElementById(index).style.color='white';
    
}
function next() {
    index++;
    if (index==hinh.length) index=0;
        document.getElementById('banner').src=hinh[index];
        document.getElementById('0').style.color='black';
        document.getElementById('1').style.color='black';
        document.getElementById('2').style.color='black';
        document.getElementById(index).style.color='white';
    
}
setInterval('next()',10000);



var c1=document.getElementById('c1');
var c2=document.getElementById('c2');
var c3=document.getElementById('c3');
const root = document.querySelector(':root');

c1.addEventListener('click', function() {
    root.style.setProperty('--color2', 'rgb(0, 255, 0)');
    localStorage.setItem('pickColor', 'rgb(0, 255, 0)');
})
c2.addEventListener('click',function(){
    root.style.setProperty('--color2','rgb(111, 0, 255)');
    localStorage.setItem('pickColor','rgb(111, 0, 255)');
})
c3.addEventListener('click',function(){
    root.style.setProperty('--color2',' rgb(255, 64, 0)');
    localStorage.setItem('pickColor',' rgb(255, 64, 0)');
})
function loadTheme() {
  if (localStorage.getItem('pickColor') != '') {
    root.style.setProperty('--color2',localStorage.getItem('pickColor'));
  }  
}
/*------------------------- ĐĂNG KÍ ---------------------*/
function kiemtra() {
    var ten  = document.getElementById("ten");
    if(ten.value == ""){
        document.getElementById("errTen").innerHTML = "Vui lòng nhập họ tên!";
        ten.focus();
        ten.style.backgroundColor = "orange";
        return false;
    }
    else if(ten.value.length < 4){
        document.getElementById("errTen").innerHTML = "Vui lòng nhập nhiều hơn 4 ký tự!";
        ten.focus();
        ten.style.backgroundColor = "orange";
        return false;
    }


    var sdt = document.getElementById("sdt");
    if(sdt.value == ""){
        document.getElementById("errSDT").innerHTML="Vui lòng nhập số điện thoại!";
        sdt.focus();
        sdt.style.backgroundColor = "orange";
        return false;
    }
    else if(isNaN(sdt.value)==true){
        document.getElementById("errSDT").innerHTML="Vui lòng nhập giá là trị số!";
        sdt.focus();
        sdt.style.backgroundColor = "orange";
        return false;
    }
    else if(parseInt(sdt.value)<0){
        document.getElementById("errSDT").innerHTML="Vui lòng nhập giá là số dương!";
        sdt.focus();
        sdt.style.backgroundColor = "orange";
        return false;
    }
    else if(sdt.value.length < 10){
        document.getElementById("errSDT").innerHTML = "Vui lòng nhập đủ ký tự!";
        sdt.focus();
        sdt.style.backgroundColor = "orange";
        return false;
    }
    return true;
}
function anloi() {
    document.getElementById("errTen").innerHTML = "";
    document.getElementById("errSDT").innerHTML = "";
}